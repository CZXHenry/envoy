package platforms

/*
#cgo CFLAGS: -DLINUX
*/
import "C"
