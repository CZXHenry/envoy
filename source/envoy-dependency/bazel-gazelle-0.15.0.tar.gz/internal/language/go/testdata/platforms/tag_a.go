//+build amd64

package platforms
