// +build !race

package racy

const RaceEnabled = false
