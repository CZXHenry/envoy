package race

import (
	"testing"
)

func TestRace(t *testing.T) {
	TriggerRace()
}
