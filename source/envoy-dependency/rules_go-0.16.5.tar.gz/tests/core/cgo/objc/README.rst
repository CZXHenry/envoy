Objective C / cgo functionality
===============================

objc_test
---------

Checks that a Go target with Objective C code (both embedded and in an
``objc_library`` ``cdeps`` dependency) compiles, links, and executes.
