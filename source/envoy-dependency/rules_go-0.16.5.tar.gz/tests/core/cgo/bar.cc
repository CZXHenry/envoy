#include <iostream>

void bar() {
  std::cout << "bar" << std::endl;
}
