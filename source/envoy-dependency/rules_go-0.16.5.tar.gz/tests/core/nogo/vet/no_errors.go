package noerrors

func Foo() bool {
	return true
}
