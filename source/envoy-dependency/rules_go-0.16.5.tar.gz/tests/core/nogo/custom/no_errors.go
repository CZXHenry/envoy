// package noerrors contains no analyzer errors.
package noerrors

func Baz() int {
	return 1
}
