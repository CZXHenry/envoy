package src

func Foo() int {
	return 1
}
