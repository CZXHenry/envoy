#include "add.h"
#include "_cgo_export.h"

int add_cpp(int a, int b) { return add(a, b); }
