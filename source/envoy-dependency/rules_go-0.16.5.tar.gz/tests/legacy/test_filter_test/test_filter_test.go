package test_filter

import "testing"

func TestShouldPass(t *testing.T) {
}

func TestShouldFail(t *testing.T) {
	t.Fail()
}
