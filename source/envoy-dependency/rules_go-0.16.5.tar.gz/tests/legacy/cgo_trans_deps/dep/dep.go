package dep

var X = 42
