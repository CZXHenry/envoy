package go_lib
