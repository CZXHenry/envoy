// Package deep provides an emulator of a computer which calculates
// answer to the ultimate question of Life, the Universe, and Everything.
package deep
