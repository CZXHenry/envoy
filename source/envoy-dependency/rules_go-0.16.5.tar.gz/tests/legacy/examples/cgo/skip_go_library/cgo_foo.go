package skip_go_library

/*
#include <stdio.h>
*/
import "C"

var _ = Type{}
