package main

import "C"
import "unsafe"

var null = unsafe.Pointer(uintptr(0))
