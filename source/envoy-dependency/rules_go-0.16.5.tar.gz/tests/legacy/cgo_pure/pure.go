//+build !cgo

package cgo_pure

var Value = 1
