// +build !go1.11

package test_version

import "testing"

func TestShouldPass(t *testing.T) {
}
